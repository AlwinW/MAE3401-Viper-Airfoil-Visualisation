#---------------------------->
#--- Plot Settings
#--- Alwin Wang MAE3401
#============================>

#--- ggplot Theme ----
# theme_set(theme_linedraw())
theme_set(theme_bw())
options(scipen = 10)